# Ada Reminder

Aplikasi alarm dan pengingat untuk **Windows 10/11** yang tetap berbunyi
walaupun jendela aplikasinya sudah ditutup. Dibuat dengan Python + Tkinter,
memakai **Windows Task Scheduler** sebagai mesin jadwal.

Versi saat ini: **2.0.0** · Bahasa Indonesia · Gratis · Tanpa akun

![Tampilan Ada Reminder](website/assets/app-main.png)

## Daftar isi

- [Fitur](#fitur)
- [Persyaratan](#persyaratan)
- [Mulai cepat (versi EXE)](#mulai-cepat-versi-exe)
- [Membuat alarm](#membuat-alarm)
- [Mengganti nada dering](#mengganti-nada-dering)
- [Mengaktifkan, menjeda, dan menghapus alarm](#mengaktifkan-menjeda-dan-menghapus-alarm)
- [Berhenti otomatis](#berhenti-otomatis)
- [Tunda dan matikan](#tunda-dan-matikan)
- [Pengaturan](#pengaturan)
- [Cara kerja Task Scheduler](#cara-kerja-task-scheduler)
- [Menjalankan dari source](#menjalankan-dari-source)
- [Membangun EXE](#membangun-exe)
- [Website dan go live](#website-dan-go-live)
- [Struktur proyek](#struktur-proyek)
- [Lokasi data](#lokasi-data)
- [Troubleshooting](#troubleshooting)
- [Keamanan dan SmartScreen](#keamanan-dan-smartscreen)

## Fitur

- **Tetap berbunyi walau aplikasi ditutup.** Setiap alarm membuat jadwal di
  Windows Task Scheduler.
- **Nada dering bisa diganti.** Mendukung WAV, MP3, WMA, M4A, AAC, dan format
  lain yang didukung pemutar media Windows (WPF MediaPlayer).
- **Tiga jenis jadwal:** sekali, setiap hari, atau hari tertentu
  (Senin–Minggu).
- **Berhenti otomatis.** Alarm harian/mingguan bisa diberi tanggal berhenti.
- **Sakelar per alarm.** Jeda alarm tanpa menghapusnya.
- **Tunda fleksibel.** Atur durasi tunda 1–60 menit.
- **Tes dering** sebelum alarm disimpan.
- **UI gelap yang rapi** dengan filter Semua/Aktif/Tidak aktif.
- **100% offline.** Tidak ada akun, telemetri, atau koneksi internet.
- **Satu file EXE.** Tidak perlu installer atau Python untuk versi jadi.

## Persyaratan

**Versi EXE**

- Windows 10 atau Windows 11 (64-bit)
- Ruang kosong sekitar 15 MB
- Windows Task Scheduler (sudah ada di Windows)

**Versi source**

- Python 3.11 atau lebih baru (diuji dengan Python 3.15)
- Tkinter (biasanya sudah termasuk dalam instalasi Python Windows)
- PyInstaller hanya diperlukan jika ingin membangun EXE

## Mulai cepat (versi EXE)

1. Unduh `Ada-Reminder-v2.0.0-win64.zip` dari folder `website/download/`
   atau dari halaman website.
2. Ekstrak ZIP ke folder yang tetap, misalnya
   `C:\Users\NamaKamu\Apps\Ada Reminder`.
3. Jalankan **`Ada Reminder.exe`**.
4. Klik **+ Alarm Baru**, isi nama dan jam, lalu simpan.
5. Tutup jendela aplikasi. Alarm tetap berjalan.

> Saat pertama dijalankan, EXE juga menyalin dirinya ke
> `%LOCALAPPDATA%\AdaReminder\Ada Reminder.exe`. Salinan ini dipakai oleh
> jadwal Windows agar alarm tetap valid jika file EXE asli dipindah atau
> dihapus. Jangan hapus folder tersebut selama masih memakai alarm.

## Membuat alarm

1. Klik **+ Alarm Baru**.
2. Isi **Nama alarm**.
3. Pilih **Jam** dan **Menit** (format 24 jam).
4. Pilih **Ulangi**:
   - **Sekali** — pilih tanggal tertentu.
   - **Setiap hari** — berulang tiap hari.
   - **Hari tertentu** — pilih chip hari yang aktif.
5. Jika perlu, aktifkan **Berhenti otomatis** dan pilih tanggal berhenti.
6. Pilih **Nada dering** atau biarkan bawaan.
7. Pastikan **Alarm aktif** menyala, lalu klik **Simpan alarm**.

Setelah disimpan, jam berikutnya akan muncul di kartu alarm. Jika waktu
tersebut sudah lewat, aplikasi akan menampilkan pesan agar kamu memilih waktu
berikutnya.

## Mengganti nada dering

1. Buka alarm (tombol **Edit**) atau buat alarm baru.
2. Di bagian **Nada dering**, klik **Pilih file**.
3. Pilih file audio dari komputer.
4. Klik **Putar** untuk mendengarkan pratinjau.
5. Klik **Simpan alarm**.

File pilihanmu **disalin** ke `%APPDATA%\AdaReminder\sounds`, jadi alarm tetap
punya suara walaupun file aslinya nanti dipindah. Tombol **Bawaan** digunakan
untuk kembali ke lonceng lembut bawaan aplikasi.

Format yang didukung di dialog: `*.wav *.mp3 *.wma *.m4a *.aac`. Format lain
yang bisa diputar pemutar media Windows juga dapat dicoba lewat pilihan
**Semua berkas**.

## Mengaktifkan, menjeda, dan menghapus alarm

- **Sakelar di kartu alarm** — nyalakan/matikan alarm dengan cepat.
- **Alarm aktif** di dialog edit — status yang sama, bisa diubah saat mengedit.
- Saat alarm dinonaktifkan, jadwal Windows untuk alarm itu dihapus. Saat
  dinyalakan lagi, jadwal dibuat ulang untuk waktu berikutnya.
- **Hapus** menghapus alarm dari daftar sekaligus menghapus jadwal dan jadwal
  tunda yang terkait.
- Filter **Semua**, **Aktif**, dan **Tidak aktif** membantu menemukan alarm.

## Berhenti otomatis

Bagian **Berhenti otomatis** tersedia untuk alarm **Setiap hari** dan
**Hari tertentu**. Pilih tanggal terakhir alarm boleh berbunyi.

- Alarm akan berhenti setelah pukul 23:59 pada tanggal tersebut.
- Di Windows Task Scheduler, tanggal ini disimpan sebagai `EndBoundary`.
- Untuk alarm **Sekali**, tanggal alarm itu sendiri sudah menjadi batas akhir.
- Alarm yang sudah melewati tanggal berhenti akan berstatus **Selesai** dan
  tidak membuat jadwal baru.

Contoh: alarm minum obat setiap hari, berhenti otomatis 30 November 2026.

## Tunda dan matikan

Saat alarm berbunyi, jendela besar muncul di atas aplikasi lain:

- **Matikan** — menghentikan dering dan menutup jendela.
- **Tunda N menit** — membuat jadwal Windows baru untuk N menit kemudian.
  Durasi N diatur di menu **Pengaturan** (1–60 menit).
- Menutup jendela dering dengan tombol X juga menghentikan suara.
- Tombol keyboard: `Esc` atau `Spasi` untuk matikan, `S` untuk tunda.

Alarm akan berhenti sendiri setelah **Dering maksimal** menit (default 5 menit)
jika dibiarkan.

## Pengaturan

Buka **Pengaturan** di sidebar:

- **Tunda alarm** — durasi tunda 1–60 menit.
- **Dering maksimal** — batas waktu dering 1–60 menit.
- **Buka folder data** — membuka `%APPDATA%\AdaReminder`.
- **Perbaiki jadwal** — menghapus semua jadwal Windows milik Ada Reminder,
  lalu membuat ulang jadwal untuk alarm yang aktif. Gunakan ini jika alarm
  terasa tidak berbunyi padahal jadwalnya benar.

## Cara kerja Task Scheduler

Untuk setiap alarm aktif, aplikasi membuat task Windows dengan nama:

```text
AdaReminder\alarm_<id_alarm>
```

Saat alarm ditunda, task tambahan dibuat:

```text
AdaReminder\snooze_<id_alarm>
```

Aksi task mengarah ke salinan aplikasi yang stabil:

```text
C:\Users\<nama>\AppData\Local\AdaReminder\Ada Reminder.exe --ring <id_alarm>
```

Untuk versi source, aksinya memakai `pythonw.exe` dan file
`ada_reminder.py`.

Task dibuat dengan opsi:

- `WakeToRun` — bangunkan komputer dari sleep jika didukung perangkat.
- `StartWhenAvailable` — jalankan sesegera mungkin jika waktu terlewat.
- `DisallowStartIfOnBatteries=false` — tetap jalan saat memakai baterai.
- `ExecutionTimeLimit=PT0S` — tidak dibatasi durasi.

Alarm **sekali** memakai `TimeTrigger`. Alarm **harian** memakai
`CalendarTrigger` dengan `ScheduleByDay`. Alarm **hari tertentu** memakai
`CalendarTrigger` dengan `ScheduleByWeek` dan pilihan hari. Untuk alarm
berulang, tanggal berhenti dipasang sebagai `EndBoundary`.

Windows Task Scheduler hanya menjalankan aplikasi pada waktu yang ditentukan.
Aplikasi tidak perlu tetap terbuka. Jika komputer mati total, alarm baru
dijalankan saat Windows menyala kembali (sesuai perilaku `StartWhenAvailable`).

## Menjalankan dari source

1. Pastikan Python 3.11+ dan Tkinter tersedia.
2. Buka folder proyek.
3. Jalankan:

```bat
Jalankan Ada Reminder.bat
```

atau langsung:

```bat
python ada_reminder.py
```

Untuk tes jendela dering tanpa membuat alarm:

```bat
python ada_reminder.py --demo
```

Untuk memicu alarm tertentu secara manual:

```bat
python ada_reminder.py --ring <id_alarm>
```

## Membangun EXE

Jalankan:

```bat
build_exe.bat
```

Script akan memasang/memperbarui PyInstaller, lalu membangun:

```text
dist\Ada Reminder.exe
```

Perintah utamanya:

```bat
python -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name "Ada Reminder" ^
  --icon "app.ico" ^
  --version-file "version_info.txt" ^
  --add-data "app.ico;." ^
  --hidden-import "core" ^
  --hidden-import "ui_main" ^
  --hidden-import "ui_ring" ^
  "ada_reminder.py"
```

Setelah build, uji EXE:

1. Jalankan `dist\Ada Reminder.exe`.
2. Buat alarm beberapa menit ke depan.
3. Tutup jendela utama.
4. Pastikan jendela dering muncul pada waktunya.
5. Cek `%APPDATA%\AdaReminder\ada.log` jika ada masalah.

## Website dan go live

Website statis ada di folder `website/`:

```text
website/
├─ index.html          # landing page + tombol unduh
├─ privasi.html        # kebijakan privasi
├─ style.css           # desain gelap/amber
├─ script.js           # menu mobile, animasi reveal, FAQ
├─ assets/             # screenshot, ikon
└─ download/           # file ZIP dan EXE yang bisa diunduh
```

### Opsi 1 — Netlify Drop (paling cepat)

1. Buka <https://app.netlify.com/drop>.
2. Seret folder `website` ke halaman tersebut.
3. Netlify memberi URL langsung. Situs bisa langsung dipakai.
4. Untuk domain sendiri, hubungkan domain di menu **Domain management**.

### Opsi 2 — GitHub Pages dengan Actions

Workflow siap pakai ada di `.github/workflows/pages.yml`.

1. Buat repository GitHub, lalu push seluruh proyek:

   ```bat
   git init
   git add .
   git commit -m "Ada Reminder v2.0.0"
   git branch -M main
   git remote add origin https://github.com/USERNAME/REPO.git
   git push -u origin main
   ```

2. Di repository, buka **Settings → Pages**.
3. Pada **Build and deployment → Source**, pilih **GitHub Actions**.
4. Push ke branch `main` atau jalankan workflow **Deploy website** secara manual.
5. Website akan tersedia di `https://USERNAME.github.io/REPO/`.

Workflow mengunggah isi folder `website` saja, jadi file build dan source tidak
ikut tampil di web.

### Opsi 3 — GitHub Pages dari folder `/docs`

Jika tidak ingin memakai Actions:

1. Salin isi `website` ke folder `docs` di root repository.
2. Di **Settings → Pages**, pilih **Deploy from a branch**.
3. Pilih branch `main` dan folder `/docs`.

### Checklist sebelum go live

- [ ] Ganti tautan unduhan jika nama file berubah.
- [ ] Pastikan `website/download/Ada-Reminder-v2.0.0-win64.zip` ada.
- [ ] Perbarui checksum SHA-256 di `index.html` setelah ZIP dibuat ulang.
- [ ] Uji tombol unduh di browser (ZIP dan EXE).
- [ ] Uji tampilan di ponsel (menu hamburger, tombol unduh).
- [ ] Cek halaman `privasi.html`.
- [ ] Pastikan file EXE di ZIP adalah build terbaru.
- [ ] Ingat: file belum ditandatangani digital, jadi SmartScreen bisa muncul.

### Membuat ulang paket ZIP

Dari PowerShell di folder proyek:

```powershell
Compress-Archive -Path "dist\Ada Reminder.exe", "README.md", "Panduan Singkat.txt" `
  -DestinationPath "website\download\Ada-Reminder-v2.0.0-win64.zip" -Force
Get-FileHash "website\download\Ada-Reminder-v2.0.0-win64.zip" -Algorithm SHA256
```

Salin hasil hash ke elemen `#checksum` di `website/index.html`.

## Struktur proyek

```text
Ada/
├─ ada_reminder.py              # entry point: UI, --ring, --demo
├─ core.py                      # data, jadwal Windows, suara, log
├─ ui_main.py                   # dashboard, dialog alarm, pengaturan
├─ ui_ring.py                   # jendela dering
├─ app.ico                      # ikon aplikasi dan EXE
├─ version_info.txt             # metadata EXE
├─ build_exe.bat                # build satu file EXE
├─ Jalankan Ada Reminder.bat    # launcher source tanpa konsol
├─ dist/
│  └─ Ada Reminder.exe          # hasil build
├─ website/                     # landing page HTML/CSS
├─ .github/workflows/pages.yml  # deploy GitHub Pages
└─ README.md
```

## Lokasi data

Data pengguna disimpan di:

```text
%APPDATA%\AdaReminder\
├─ alarms.json          # daftar alarm
├─ settings.json        # durasi tunda & dering maksimal
├─ sounds\              # nada dering bawaan dan yang diimpor
├─ tasks\               # file XML jadwal Windows
├─ ada.log              # log aplikasi
└─ play_sound.ps1       # helper pemutar audio non-WAV
```

Salinan aplikasi yang stabil:

```text
%LOCALAPPDATA%\AdaReminder\Ada Reminder.exe
```

Jadwal Windows:

```text
Task Scheduler Library → AdaReminder
```

Jangan menghapus folder data saat aplikasi sedang berjalan. Untuk menghapus
semua data, tutup aplikasi terlebih dahulu, lalu hapus folder
`%APPDATA%\AdaReminder` dan `%LOCALAPPDATA%\AdaReminder`.

## Troubleshooting

### Alarm tidak berbunyi

1. Pastikan alarm berstatus **Aktif** (sakelar menyala).
2. Buka **Pengaturan → Perbaiki jadwal**.
3. Pastikan Windows Task Scheduler menampilkan task
   `AdaReminder\alarm_<id>`.
4. Cek `%APPDATA%\AdaReminder\ada.log`.
5. Pastikan file
   `%LOCALAPPDATA%\AdaReminder\Ada Reminder.exe` masih ada.
6. Pastikan jam Windows dan zona waktu sudah benar.

### Alarm berbunyi tetapi tidak ada suara

- Cek volume Windows dan perangkat output.
- Buka alarm, klik **Putar** untuk menguji nada dering.
- Jika memakai MP3/WMA/M4A, pastikan pemutar media Windows berfungsi normal.
- Coba kembali ke nada dering **Bawaan**.
- Periksa file di `%APPDATA%\AdaReminder\sounds`.

### Muncul dua jendela utama

Aplikasi memakai mutex `Local\AdaReminder.UI`. Jika jendela lama masih
berjalan, cek taskbar. Tutup jendela lama terlebih dahulu.

### EXE lambat terbuka

EXE dibuat dengan PyInstaller mode `--onefile`, sehingga perlu mengekstrak
komponen ke folder sementara saat pertama dijalankan. Waktu buka normal sekitar
2–4 detik.

### Windows Defender atau SmartScreen menolak file

Lihat bagian berikut.

## Keamanan dan SmartScreen

File EXE belum ditandatangani dengan sertifikat code signing. Windows dapat
menampilkan **Windows protected your PC** saat pertama kali dijalankan.

Langkah yang aman:

1. Pastikan file diunduh dari sumber yang kamu percaya.
2. Periksa checksum SHA-256 yang tertera di halaman unduhan.
3. Klik **More info**, lalu **Run anyway**.
4. Jika tetap ragu, jalankan versi source setelah memeriksa kode Python-nya.

Untuk distribusi publik yang lebih mulus, pertimbangkan code signing certificate
(EV/OV) dan membangun installer seperti Inno Setup atau MSIX.

## Catatan pengembangan

- Kode menggunakan Python standard library. Tidak ada dependensi runtime
  eksternal.
- Semua proses `schtasks` dan PowerShell dijalankan tanpa jendela konsol
  (`CREATE_NO_WINDOW`).
- Format non-WAV diputar lewat helper PowerShell `play_sound.ps1` yang otomatis
  dibuat di folder data.
- Nada dering bawaan dibuat secara prosedural sebagai file WAV, sehingga tidak
  perlu menyertakan file audio berhak cipta.
- Ikon dan ilustrasi UI digambar langsung dengan Tkinter Canvas.

## Lisensi

Proyek ini disediakan untuk penggunaan pribadi. Jika kamu ingin
mempublikasikannya sebagai proyek open source, tambahkan file `LICENSE` sesuai
lisensi yang kamu pilih.
